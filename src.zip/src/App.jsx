import React from 'react'
import Section from './Section1.jsx/Section'

const App = () => {
    return (
        <section >
            <Section/>
        </section>
    )
}

export default App
